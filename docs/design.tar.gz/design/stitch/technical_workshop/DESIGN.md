---
name: Technical Workshop
colors:
  surface: '#f8f9ff'
  surface-dim: '#cfdbee'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dee9fd'
  surface-container-highest: '#d8e3f7'
  on-surface: '#111c2a'
  on-surface-variant: '#444656'
  inverse-surface: '#263140'
  inverse-on-surface: '#eaf1ff'
  outline: '#747688'
  outline-variant: '#c4c5d9'
  surface-tint: '#2246f4'
  primary: '#002dcf'
  on-primary: '#ffffff'
  primary-container: '#2447f5'
  on-primary-container: '#d4d7ff'
  inverse-primary: '#bbc3ff'
  secondary: '#725c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed74c'
  on-secondary-container: '#735d00'
  tertiary: '#3d4857'
  on-tertiary: '#ffffff'
  tertiary-container: '#55606f'
  on-tertiary-container: '#cfdaed'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dee0ff'
  primary-fixed-dim: '#bbc3ff'
  on-primary-fixed: '#000f5d'
  on-primary-fixed-variant: '#002dcd'
  secondary-fixed: '#ffe07e'
  secondary-fixed-dim: '#e9c339'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#564500'
  tertiary-fixed: '#d8e3f6'
  tertiary-fixed-dim: '#bcc7d9'
  on-tertiary-fixed: '#111c29'
  on-tertiary-fixed-variant: '#3d4856'
  background: '#f8f9ff'
  on-background: '#111c2a'
  surface-variant: '#d8e3f7'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  mono-data:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  mono-data-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.01em
spacing:
  gutter: 1rem
  gutter-mobile: 0.5rem
  margin: 1.5rem
  margin-mobile: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes an exact, disciplined, and utilitarian workshop aesthetic. Tailored for technical practitioners, builders, and specialists who require rapid access to dense arrays of single-purpose utilities, the interface prioritizes immediate legibility and operational frictionlessness over ambient decoration. 

The emotional tone is calm, analytical, and highly structured—evoking the tactile precision of draftsmanship tools, index card catalogues, and calibrated hardware. The design movement is structural minimalism merged with technical workshop ergonomics: strict flat planes, crisp 1-pixel rules, deliberate negative space, and unambiguous visual boundaries. Information is presented with zero artificial elevation, relying entirely on geometric containment, sharp borders, and disciplined typographic hierarchy to convey order.

## Colors

The palette is derived from physical workshop media—blueprint paper, engineering vellum, and industrial ink:

- **Canvas Background (`#EDF0F3`):** The structural floor of the application, providing a cool, low-strain paper tone behind all operational panels.
- **Panel Surface (`#FFFFFF`):** High-clarity white reserved for active tool containers, work tables, and input groupings.
- **Ink Primary (`#101828`):** High-density carbon black for primary headlines, data values, and active interface labels.
- **Muted Neutral (`#4A5565`):** Calibrated gray for meta-labels, secondary descriptions, units of measurement, and inactive tool states.
- **Hairline Border (`#BCC5D0`):** Subtle internal divider tone used for tabular division, subtle cell separators, and passive grid lines.
- **Strong Border (`#6B7686`):** The primary boundary color used for interactive controls, panel enclosures, frame perimeters, and active structural boundaries.
- **Cobalt Primary (`#2447F5`):** High-acuity electric cobalt for terminal actions, focus states, selected tool indicators, and active toggles.
- **Marker Highlight (`#FFD84D`):** Accent highlighter yellow applied sparingly for active filters, search matches, and operational badges.

## Typography

The type scale strictly respects a structural floor of 12px. No typographic element anywhere in the interface renders below this baseline, preserving high visual acuity across dense layouts.

- **Primary Interface Type:** Rendered via an architectural sans-serif with geometric precision and tight rhythm. Used for panel headers, descriptive body text, index names, and category structures.
- **Technical & Data Type:** Rendered via a clean monospaced engine across all tool parameters, telemetry data, numerical outputs, keyboard accelerators, and system tags.
- **Letter Spacing:** Monospaced and micro-labels utilize positive tracking (+0.01em to +0.02em) to maintain crisp character separation at 12px, while headings enforce tight, assertive negative tracking (-0.01em to -0.02em).

## Layout & Spacing

The layout is structured around an exact fixed-grid workshop model that maximizes high-density utility indexing:

- **Desktop (1024px+):** A 12-column modular grid with 1rem gutters and 1.5rem canvas margins. Multi-column index boards maintain fixed, predictable tool modularity (1-column utility rows, 2-column or 3-column composite cards, 4-column master inspector drawers).
- **Tablet (768px – 1023px):** Collapses into an 8-column system with 0.75rem gutters and 1rem canvas margins. Secondary tool trays collapse to drawer overlays.
- **Mobile (< 768px):** A single-column or 2-column micro-index grid with 0.5rem gutters and 0.75rem margins. Stacked rows replace multi-pane arrangements.
- **Internal Spacing Discipline:** Tight rhythm based on 4px (`space-xs`), 8px (`space-sm`), 12px (`space-md`), and 16px (`space-lg`). Component interiors optimize information density: tools present inputs with `space-sm` or `space-md` paddings, keeping vertical footprints minimal to ensure maximum index visibility above the viewport fold.

## Elevation & Depth

This design system rejects drop shadows, blurred ambient lighting, and elevated 3D depth models. Hierarchy is established strictly through 2D structural planes and 1px borders:

- **Surface Layering:** The foundational floor is Canvas Paper (`#EDF0F3`). Content panels, tool cards, and modal inspector drawers sit directly on this canvas as White (`#FFFFFF`) islands.
- **Boundary Precision:** Structural cards, active modules, and tool slots use a continuous 1px solid border (`#6B7686`). Subordinate sectioning, list splits, and internal grid lines use a 1px hairline border (`#BCC5D0`).
- **Focus & Selection:** Active tools, focused text inputs, and highlighted items achieve prominence via high-contrast border switches (transitioning from `#6B7686` to `#2447F5`) paired with an interior or exterior 1px solid focus rule, never soft-blur glow halos.
- **Overlay Panels:** Flyouts and temporary inspector panels use a 1px solid `#101828` border with a crisp, opaque `#FFFFFF` fill, avoiding glassmorphic blur or dropshadow diffusion.

## Shapes

The design system enforces a zero-radius geometry (`0px` / Sharp):

- Every panel, input, button, chip, badge, and tab terminates in exact 90-degree right angles.
- This clean, hard-edged silhouette reinforces the workshop-tool metaphor, evokes technical calibration sheets, and allows adjacent control groups to align flush along shared 1px borders without visual gaps or rounding artifacts.

## Components

### Buttons & Trigger Controls
- **Primary Action:** Solid `#2447F5` background, `#FFFFFF` text, 0px radius, 1px solid `#2447F5` border. On hover, background deepens to `#1A37C7`.
- **Secondary / Utility Button:** Solid `#FFFFFF` background, `#101828` text, 1px solid `#6B7686` border. Hover changes background to `#EDF0F3`. Active changes border to `#101828`.
- **Destructive Button:** `#FFFFFF` surface with `#D92D20` border and text. Hover applies 1px solid `#D92D20` with `#FEF3F2` background.
- **Dimensions:** Compact 28px height (compact tool strip) or standard 32px height (standard action). Padding is 8px horizontal (`space-sm`), font is `Geist` 12px.

### Form Inputs & Selectors
- **Input Fields:** `#FFFFFF` background, 1px solid `#6B7686` border, 0px radius. Height 32px, text `#101828` in `Geist` 12px or 13px. Focus states shift border to 1px solid `#2447F5` with a 1px interior accent guideline.
- **Muted Labeling:** Field labels render in `Hanken Grotesk` 12px medium (`#4A5565`) stacked 4px directly above the control, with zero arbitrary margin.

### Checkboxes & Radio Controls
- **Checkboxes:** Exact 14x14px square, 0px radius, 1px solid `#6B7686` border, `#FFFFFF` background. Selected state applies `#2447F5` fill with a sharp white checkmark vector.
- **Radio Buttons:** Exact 14x14px square, 0px radius, 1px solid `#6B7686` border (consistent with the strict rectilinear workshop grammar). Selected state renders an inner 6x6px solid square in `#2447F5`.

### Chips, Tags & Badges
- **Status / Category Chips:** Rectangular badges, height 20px, 0px radius, 1px solid `#BCC5D0`, `#FFFFFF` background, `#4A5565` monospace text (12px).
- **Marker Highlighting:** Filtered search tokens and alert badges use `#FFD84D` background with 1px solid `#101828` border and `#101828` text for instant ocular discovery.

### Lists & Index Tables
- **Dense Tool Index:** Grid or list rows separated by 1px solid `#BCC5D0` horizontal rules. Row height 36px. Hover state shifts row background from `#FFFFFF` to `#EDF0F3`.
- **Table Cells:** Numeric data is right-aligned in `Geist` 12px. Categorical tool titles are left-aligned in `Hanken Grotesk` 13px.

### Cards & Tool Enclosures
- **Utility Panel:** `#FFFFFF` background, 1px solid `#6B7686` perimeter border. Header bar separated by 1px solid `#BCC5D0` baseline divider with a height of 32px.
- **Nested Controls:** Secondary setting blocks within cards sit on `#EDF0F3` inset trays bounded by 1px solid `#BCC5D0`.

### Key-Value Parameter Displays
- Specialized component for technical readouts. Left side contains parameter name in `#4A5565` 12px uppercase; right side contains value in `#101828` monospace 12px, separated by a dotted or hairline 1px `#BCC5D0` horizontal leader line.